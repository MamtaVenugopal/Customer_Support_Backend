"""Archive extraction and waveform DataLoaders for 1D U-Net ASD."""

from __future__ import annotations

import os
import random
import re
import zipfile
from pathlib import Path

import librosa
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset, Subset

from config_1d import Paths, WaveformConfig


def extract_if_needed(zip_path: Path, dest_dir: Path, marker_relpath: str | None = None) -> Path:
    zip_path = Path(zip_path)
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    marker = dest_dir / marker_relpath if marker_relpath else None
    if marker and marker.exists():
        return dest_dir
    if not zip_path.is_file():
        raise FileNotFoundError(f"Missing zip: {zip_path}")
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(dest_dir)
    return dest_dir


def eval_bearing_root(unpack_parent: Path) -> Path:
    return Path(unpack_parent) / "bearing"


def list_wavs(directory: Path) -> list[Path]:
    directory = Path(directory)
    if not directory.is_dir():
        return []
    files = [directory / f for f in os.listdir(directory) if f.lower().endswith(".wav")]
    return sorted(files)


def ensure_eval_data(paths: Paths) -> Path:
    parent = paths.unpack_eval_dir
    extract_if_needed(paths.eval_train_zip, parent, marker_relpath="bearing/train")
    extract_if_needed(paths.eval_test_zip, parent, marker_relpath="bearing/test")
    root = eval_bearing_root(parent)
    if not (root / "train").is_dir() or not (root / "test").is_dir():
        raise RuntimeError(f"Expected bearing/train and bearing/test under {parent}")
    return root


def ensure_dev_data(paths: Paths) -> Path | None:
    if paths.dev_zip is None or not paths.dev_zip.is_file():
        return None
    parent = paths.unpack_dev_dir
    extract_if_needed(paths.dev_zip, parent, marker_relpath="bearing/test")
    root = parent / "bearing"
    return root if (root / "test").is_dir() else None


def fix_waveform_length(waveform: np.ndarray, target_len: int) -> np.ndarray:
    if len(waveform) < target_len:
        return np.pad(waveform, (0, target_len - len(waveform)), mode="constant")
    return waveform[:target_len]


def normalize_per_sample(waveform: np.ndarray) -> np.ndarray:
    m = waveform.mean()
    s = waveform.std() + 1e-6
    return ((waveform - m) / s).astype(np.float32)


class WaveformDataset(Dataset):
    """Loads wav, returns normalized waveform tensor (1, T)."""

    def __init__(
        self,
        wav_paths: list[Path],
        feat: WaveformConfig,
        label: int | None = None,
        labels: list[int] | None = None,
    ) -> None:
        self.paths = [Path(p) for p in wav_paths]
        self.feat = feat
        self.label = label
        self.labels = labels
        if self.labels is not None and len(self.labels) != len(self.paths):
            raise ValueError("labels length must match wav_paths")

    def __len__(self) -> int:
        return len(self.paths)

    def __getitem__(self, idx: int) -> dict:
        path = self.paths[idx]
        wav, _ = librosa.load(str(path), sr=self.feat.sample_rate, mono=True)
        wav = fix_waveform_length(wav, self.feat.fixed_length)
        wav = normalize_per_sample(wav)
        x = torch.from_numpy(wav).unsqueeze(0)
        out: dict = {"x": x, "path": str(path), "name": path.name}
        if self.labels is not None:
            out["y"] = torch.tensor(self.labels[idx], dtype=torch.long)
        elif self.label is not None:
            out["y"] = torch.tensor(self.label, dtype=torch.long)
        return out


def train_val_indices(n: int, val_fraction: float, seed: int) -> tuple[list[int], list[int]]:
    idx = list(range(n))
    rng = random.Random(seed)
    rng.shuffle(idx)
    n_val = int(round(n * val_fraction))
    n_val = max(1, n_val) if n > 1 else 0
    if n_val >= n:
        n_val = max(1, n // 10)
    val_idx = idx[:n_val]
    train_idx = idx[n_val:]
    if not train_idx:
        train_idx = val_idx
        val_idx = []
    return train_idx, val_idx


def split_dataset(ds: Dataset, train_idx: list[int], val_idx: list[int]) -> tuple[Subset, Subset | None]:
    train_subset: Subset = Subset(ds, train_idx)
    val_subset: Subset | None = Subset(ds, val_idx) if val_idx else None
    return train_subset, val_subset


def make_train_loaders(
    train_wavs: list[Path],
    feat: WaveformConfig,
    batch_size: int,
    val_fraction: float,
    seed: int,
    num_workers: int,
) -> tuple[DataLoader, DataLoader | None]:
    base = WaveformDataset(train_wavs, feat)
    tr_idx, va_idx = train_val_indices(len(base), val_fraction, seed)
    tr_sub, va_sub = split_dataset(base, tr_idx, va_idx)
    train_loader = DataLoader(
        tr_sub,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )
    val_loader: DataLoader | None = None
    if va_sub is not None and len(va_idx) > 0:
        val_loader = DataLoader(
            va_sub,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=torch.cuda.is_available(),
        )
    return train_loader, val_loader


def make_simple_loader(
    wavs: list[Path],
    feat: WaveformConfig,
    batch_size: int,
    num_workers: int,
    label: int | None = None,
    labels: list[int] | None = None,
    shuffle: bool = False,
) -> DataLoader:
    ds = WaveformDataset(wavs, feat, label=label, labels=labels)
    return DataLoader(
        ds,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )


def make_dev_manifest_loader(
    manifest: pd.DataFrame,
    feat: WaveformConfig,
    batch_size: int,
    num_workers: int,
) -> DataLoader:
    paths = [Path(p) for p in manifest["path"].tolist()]
    labels = [int(x) for x in manifest["label"].tolist()]
    return make_simple_loader(
        paths,
        feat,
        batch_size=batch_size,
        num_workers=num_workers,
        labels=labels,
        shuffle=False,
    )


_DEV_LABEL_RE = re.compile(r"_test_(normal|anomaly)_", re.IGNORECASE)


def label_from_dev_test_filename(name: str) -> int:
    m = _DEV_LABEL_RE.search(name)
    if not m:
        raise ValueError(f"Cannot parse dev label from: {name}")
    return 0 if m.group(1).lower() == "normal" else 1


def section_from_dev_test_filename(name: str) -> str:
    m = re.match(r"section_(\d+)_", name)
    if not m:
        raise ValueError(f"Cannot parse section from: {name}")
    return m.group(1)


def load_dev_test_manifest(test_dir: Path) -> pd.DataFrame:
    rows = []
    for p in list_wavs(test_dir):
        rows.append(
            {
                "path": str(p),
                "name": p.name,
                "section": section_from_dev_test_filename(p.name),
                "label": label_from_dev_test_filename(p.name),
            }
        )
    return pd.DataFrame(rows)


def describe_attributes_csv(csv_path: Path, max_rows: int = 5) -> pd.DataFrame:
    return pd.read_csv(csv_path).head(max_rows)
