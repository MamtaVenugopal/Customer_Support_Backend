"""Human-readable dataset and task description for 1D waveform ASD."""

from __future__ import annotations

DATASET_AND_USE_CASE = """
## What this data is

The archives follow **DCASE 2022 Challenge Task 2** style bearing audio:

- **Modality**: single-channel **waveform audio**, around **10s** per clip.
- **Machine type here**: **bearing**.
- **Training split used here**: `eval_data_bearing_train.zip` -> `bearing/train` (sections 03-05, normal clips).
- **Unlabeled scoring split**: `eval_data_bearing_test.zip` -> `bearing/test`.
- **Optional labeled metrics**: `dev_bearing.zip` -> dev `bearing/test` (sections 00-02 with normal/anomaly labels in filenames).

---

## Problem statement

Train an **unsupervised 1D waveform U-Net autoencoder** on normal clips only.
At inference, compute per-clip reconstruction MSE (higher means more anomalous).
"""


def get_dataset_overview_markdown() -> str:
    return DATASET_AND_USE_CASE.strip()
