"""1D U-Net autoencoder for waveform reconstruction."""

from __future__ import annotations

import torch
import torch.nn as nn


class ConvBlock1D(nn.Module):
    def __init__(self, in_ch: int, out_ch: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm1d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv1d(out_ch, out_ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm1d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class UNet1DAutoencoder(nn.Module):
    """
    1D U-Net autoencoder for (B, 1, T) inputs where T is divisible by 8.
    """

    def __init__(self, in_channels: int = 1, base_channels: int = 32) -> None:
        super().__init__()
        b = base_channels
        self.enc1 = ConvBlock1D(in_channels, b)
        self.pool1 = nn.MaxPool1d(2)
        self.enc2 = ConvBlock1D(b, b * 2)
        self.pool2 = nn.MaxPool1d(2)
        self.enc3 = ConvBlock1D(b * 2, b * 4)
        self.pool3 = nn.MaxPool1d(2)
        self.bottleneck = ConvBlock1D(b * 4, b * 8)

        self.up3 = nn.ConvTranspose1d(b * 8, b * 4, kernel_size=2, stride=2)
        self.dec3 = ConvBlock1D(b * 8, b * 4)
        self.up2 = nn.ConvTranspose1d(b * 4, b * 2, kernel_size=2, stride=2)
        self.dec2 = ConvBlock1D(b * 4, b * 2)
        self.up1 = nn.ConvTranspose1d(b * 2, b, kernel_size=2, stride=2)
        self.dec1 = ConvBlock1D(b * 2, b)
        self.out_conv = nn.Conv1d(b, in_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        c1 = self.enc1(x)
        p1 = self.pool1(c1)
        c2 = self.enc2(p1)
        p2 = self.pool2(c2)
        c3 = self.enc3(p2)
        p3 = self.pool3(c3)
        bn = self.bottleneck(p3)

        u3 = self.up3(bn)
        u3 = torch.cat([u3, c3], dim=1)
        d3 = self.dec3(u3)

        u2 = self.up2(d3)
        u2 = torch.cat([u2, c2], dim=1)
        d2 = self.dec2(u2)

        u1 = self.up1(d2)
        u1 = torch.cat([u1, c1], dim=1)
        d1 = self.dec1(u1)
        return self.out_conv(d1)

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        c1 = self.enc1(x)
        p1 = self.pool1(c1)
        c2 = self.enc2(p1)
        p2 = self.pool2(c2)
        c3 = self.enc3(p2)
        p3 = self.pool3(c3)
        return self.bottleneck(p3)


def build_model(in_channels: int = 1, base_channels: int = 32) -> UNet1DAutoencoder:
    return UNet1DAutoencoder(in_channels=in_channels, base_channels=base_channels)


def count_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def model_summary_text(model: nn.Module, sample: torch.Tensor) -> str:
    lines = [repr(model), "", f"Trainable parameters: {count_parameters(model):,}"]
    with torch.no_grad():
        out = model(sample)
        lines.append(f"Sample forward: in {tuple(sample.shape)} -> out {tuple(out.shape)}")
    return "\n".join(lines)
