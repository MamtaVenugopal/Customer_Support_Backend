"""Model parameter counts and optional torchinfo summary for 1D U-Net."""

from __future__ import annotations

import torch.nn as nn

from model_unet_1d import count_parameters


def print_model_summary(
    model: nn.Module,
    *,
    input_shape: tuple[int, int, int] = (1, 1, 65_536),
    device: str = "cpu",
) -> None:
    print(f"Trainable parameters: {count_parameters(model):,}")
    try:
        from torchinfo import summary  # type: ignore

        summary(model, input_size=input_shape, device=device)
    except ImportError:
        print("(Install `torchinfo` for a full layer-wise summary: pip install torchinfo)")
