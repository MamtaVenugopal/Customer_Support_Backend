"""Explainability helpers for 1D waveform U-Net reconstruction."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import librosa
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config_1d import WaveformConfig
from data_loading_1d import fix_waveform_length, normalize_per_sample


def wav_path_to_tensor(wav_path: str | Path, feat: WaveformConfig, device: torch.device) -> torch.Tensor:
    y, _ = librosa.load(str(wav_path), sr=feat.sample_rate, mono=True)
    y = fix_waveform_length(y, feat.fixed_length)
    y = normalize_per_sample(y)
    x = torch.from_numpy(y).unsqueeze(0).unsqueeze(0).float().to(device)
    return x


@torch.no_grad()
def reconstruct(model: nn.Module, x: torch.Tensor) -> torch.Tensor:
    model.eval()
    return model(x)


def squared_error_waveform(x: torch.Tensor, recon: torch.Tensor) -> np.ndarray:
    err = (recon - x) ** 2
    return err.squeeze(0).squeeze(0).detach().cpu().numpy()


def input_gradient_saliency(model: nn.Module, x: torch.Tensor, *, squared: bool = True) -> np.ndarray:
    model.eval()
    x_in = x.detach().clone().requires_grad_(True)
    recon = model(x_in)
    loss = F.mse_loss(recon, x_in)
    loss.backward()
    g = x_in.grad
    if g is None:
        raise RuntimeError("Gradients not computed")
    sal = g.abs()
    if squared:
        sal = sal**2
    return sal.squeeze(0).squeeze(0).detach().cpu().numpy()


def plot_reconstruction_explanation(
    x: torch.Tensor,
    recon: torch.Tensor,
    *,
    saliency: np.ndarray | None = None,
    title: str = "",
    figsize: tuple[float, float] = (14, 8),
) -> plt.Figure:
    x_np = x.squeeze(0).squeeze(0).detach().cpu().numpy()
    r_np = recon.squeeze(0).squeeze(0).detach().cpu().numpy()
    err = squared_error_waveform(x, recon)

    nrows = 4 if saliency is not None else 3
    fig, axes = plt.subplots(nrows, 1, figsize=figsize, sharex=True)
    axes = np.atleast_1d(axes)

    axes[0].plot(x_np, linewidth=0.6)
    axes[0].set_title("Input waveform (normalized)")
    axes[0].set_ylabel("Amplitude")

    axes[1].plot(r_np, linewidth=0.6, color="tab:orange")
    axes[1].set_title("Reconstruction")
    axes[1].set_ylabel("Amplitude")

    axes[2].plot(err, linewidth=0.6, color="tab:red")
    axes[2].set_title("Squared error over time")
    axes[2].set_ylabel("Error")

    if saliency is not None:
        axes[3].plot(saliency, linewidth=0.6, color="tab:green")
        axes[3].set_title("|grad_x MSE| saliency")
        axes[3].set_ylabel("Saliency")

    axes[-1].set_xlabel("Sample index")
    clip_mse = float(torch.mean((recon - x) ** 2).item())
    fig.suptitle(f"{title}\nclip MSE = {clip_mse:.6f}")
    fig.tight_layout()
    return fig


def explain_wav_file(
    model: nn.Module,
    wav_path: str | Path,
    feat: WaveformConfig,
    device: torch.device,
    *,
    with_saliency: bool = True,
    title: str | None = None,
) -> dict[str, Any]:
    path = Path(wav_path)
    x = wav_path_to_tensor(path, feat, device)
    recon = reconstruct(model, x)
    mse = float(torch.mean((recon - x) ** 2).item())
    sal = None
    if with_saliency:
        model.zero_grad(set_to_none=True)
        sal = input_gradient_saliency(model, x)
    fig = plot_reconstruction_explanation(
        x,
        recon,
        saliency=sal,
        title=title or path.name,
    )
    return {"x": x, "recon": recon, "mse": mse, "saliency": sal, "figure": fig, "path": str(path)}
