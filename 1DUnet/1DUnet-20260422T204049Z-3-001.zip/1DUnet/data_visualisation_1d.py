"""Waveform visualization helpers for 1D U-Net ASD."""

from __future__ import annotations

from pathlib import Path

import librosa
import matplotlib.pyplot as plt
import numpy as np

from config_1d import WaveformConfig
from data_loading_1d import fix_waveform_length


def plot_waveform(
    wav_path: str | Path,
    feat: WaveformConfig,
    title: str | None = None,
    figsize: tuple[float, float] = (12, 3.5),
) -> plt.Figure:
    wav_path = Path(wav_path)
    y, sr = librosa.load(str(wav_path), sr=feat.sample_rate, mono=True)
    y = fix_waveform_length(y, feat.fixed_length)
    t = np.arange(len(y)) / sr

    fig, ax = plt.subplots(1, 1, figsize=figsize)
    ax.plot(t, y, linewidth=0.5)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    ax.set_title("Waveform")
    fig.suptitle(title or wav_path.name)
    fig.tight_layout()
    return fig
