"""Training loop for spectrogram reconstruction."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
from torch.optim import Adam
from torch.utils.data import DataLoader
from tqdm.auto import tqdm


def reconstruction_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    return nn.functional.mse_loss(pred, target)


def train_one_epoch(
    model: nn.Module,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
) -> float:
    model.train()
    total = 0.0
    n = 0
    for batch in loader:
        x = batch["x"].to(device)
        optimizer.zero_grad(set_to_none=True)
        recon = model(x)
        loss = reconstruction_loss(recon, x)
        loss.backward()
        optimizer.step()
        total += float(loss.item()) * x.size(0)
        n += x.size(0)
    return total / max(n, 1)


@torch.no_grad()
def validate(model: nn.Module, loader: DataLoader, device: torch.device) -> float:
    model.eval()
    total = 0.0
    n = 0
    for batch in loader:
        x = batch["x"].to(device)
        recon = model(x)
        loss = reconstruction_loss(recon, x)
        total += float(loss.item()) * x.size(0)
        n += x.size(0)
    return total / max(n, 1)


def fit(
    model: nn.Module,
    train_loader: DataLoader,
    val_loader: DataLoader | None,
    *,
    epochs: int,
    lr: float,
    device: torch.device,
    checkpoint_path: Path | None = None,
) -> dict[str, Any]:
    optimizer = Adam(model.parameters(), lr=lr)
    history: dict[str, list[float]] = {"train_loss": [], "val_loss": []}
    best_val = float("inf")
    ckpt_path = Path(checkpoint_path) if checkpoint_path else None

    epoch_bar = tqdm(range(1, epochs + 1), desc="epochs", position=0)
    for epoch in epoch_bar:
        tr = train_one_epoch(model, train_loader, optimizer, device)
        history["train_loss"].append(tr)
        msg = f"train {tr:.5f}"
        if val_loader is not None:
            va = validate(model, val_loader, device)
            history["val_loss"].append(va)
            msg += f" | val {va:.5f}"
            if va < best_val and ckpt_path is not None:
                best_val = va
                ckpt_path.parent.mkdir(parents=True, exist_ok=True)
                torch.save({"model": model.state_dict(), "epoch": epoch, "val_loss": va}, ckpt_path)
        epoch_bar.set_postfix_str(msg)

    if ckpt_path is not None and ckpt_path.is_file() and val_loader is not None:
        state = torch.load(ckpt_path, map_location=device)
        model.load_state_dict(state["model"])
    return {"history": history, "checkpoint": str(ckpt_path) if ckpt_path else ""}
