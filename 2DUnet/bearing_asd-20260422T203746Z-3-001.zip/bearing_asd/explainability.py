"""Post-hoc explanations for the mel U-Net autoencoder (reconstruction-based ASD)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import librosa
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from bearing_asd.config import AudioFeatureConfig
from bearing_asd.data_loading import fix_time_frames, normalize_per_sample, waveform_to_log_mel


def wav_path_to_tensor(wav_path: str | Path, feat: AudioFeatureConfig, device: torch.device) -> torch.Tensor:
    """Single clip -> normalized log-mel batch (1, 1, n_mels, T)."""
    y, sr = librosa.load(str(wav_path), sr=feat.sample_rate, mono=True)
    spec = waveform_to_log_mel(y, sr, feat)
    spec = fix_time_frames(spec, feat.mel_time_frames)
    spec = normalize_per_sample(spec)
    x = torch.from_numpy(spec).unsqueeze(0).unsqueeze(0).float().to(device)
    return x


@torch.no_grad()
def reconstruct(model: nn.Module, x: torch.Tensor) -> torch.Tensor:
    model.eval()
    return model(x)


def squared_error_map(x: torch.Tensor, recon: torch.Tensor) -> np.ndarray:
    """Per-bin squared error, shape (n_mels, time)."""
    err = (recon - x) ** 2
    return err.squeeze(0).squeeze(0).detach().cpu().numpy()


def input_gradient_saliency(
    model: nn.Module,
    x: torch.Tensor,
    *,
    squared: bool = True,
) -> np.ndarray:
    """
    Gradient of reconstruction MSE w.r.t. input mel (approx. local sensitivity).

    High values indicate regions that strongly influence the reconstruction loss.
    """
    model.eval()
    x_in = x.detach().clone().requires_grad_(True)
    recon = model(x_in)
    loss = F.mse_loss(recon, x_in)
    loss.backward()
    g = x_in.grad
    if g is None:
        raise RuntimeError("Gradients not computed")
    sal = g.abs()
    if squared:
        sal = sal ** 2
    return sal.squeeze(0).squeeze(0).detach().cpu().numpy()


def plot_reconstruction_explanation(
    x: torch.Tensor,
    recon: torch.Tensor,
    *,
    saliency: np.ndarray | None = None,
    title: str = "",
    figsize: tuple[float, float] = (14, 4),
) -> plt.Figure:
    """Plot input mel, reconstruction, per-bin squared error, optional saliency."""
    x_np = x.squeeze(0).squeeze(0).detach().cpu().numpy()
    r_np = recon.squeeze(0).squeeze(0).detach().cpu().numpy()
    err = squared_error_map(x, recon)

    ncols = 4 if saliency is not None else 3
    fig, axes = plt.subplots(1, ncols, figsize=figsize)
    vmin = min(x_np.min(), r_np.min())
    vmax = max(x_np.max(), r_np.max())

    im0 = axes[0].imshow(x_np, aspect="auto", origin="lower", cmap="magma", vmin=vmin, vmax=vmax)
    axes[0].set_title("Input (norm. log-mel)")
    fig.colorbar(im0, ax=axes[0], fraction=0.046)

    im1 = axes[1].imshow(r_np, aspect="auto", origin="lower", cmap="magma", vmin=vmin, vmax=vmax)
    axes[1].set_title("Reconstruction")
    fig.colorbar(im1, ax=axes[1], fraction=0.046)

    im2 = axes[2].imshow(err, aspect="auto", origin="lower", cmap="hot")
    axes[2].set_title("Squared error (explainability)")
    fig.colorbar(im2, ax=axes[2], fraction=0.046)

    if saliency is not None:
        im3 = axes[3].imshow(saliency, aspect="auto", origin="lower", cmap="viridis")
        axes[3].set_title("|∇_x MSE| (saliency)")
        fig.colorbar(im3, ax=axes[3], fraction=0.046)

    for ax in axes:
        ax.set_xlabel("Time frame")
        ax.set_ylabel("Mel bin")

    clip_mse = float(torch.mean((recon - x) ** 2).item())
    fig.suptitle(f"{title}\nclip MSE (anomaly score component) = {clip_mse:.6f}")
    fig.tight_layout()
    return fig


def explain_wav_file(
    model: nn.Module,
    wav_path: str | Path,
    feat: AudioFeatureConfig,
    device: torch.device,
    *,
    with_saliency: bool = True,
    title: str | None = None,
) -> dict[str, Any]:
    """Load one wav, run recon + optional saliency, return tensors and clip MSE."""
    path = Path(wav_path)
    x = wav_path_to_tensor(path, feat, device)
    recon = reconstruct(model, x)
    mse = float(torch.mean((recon - x) ** 2).item())
    sal = None
    if with_saliency:
        model.zero_grad(set_to_none=True)
        sal = input_gradient_saliency(model, x)
    fig = plot_reconstruction_explanation(
        x,
        recon,
        saliency=sal,
        title=title or path.name,
    )
    return {"x": x, "recon": recon, "mse": mse, "saliency": sal, "figure": fig, "path": str(path)}
