"""Anomaly scores from reconstruction error and ROC metrics."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import auc, roc_curve
from torch.utils.data import DataLoader


@torch.no_grad()
def anomaly_scores(model: nn.Module, loader: DataLoader, device: torch.device) -> pd.DataFrame:
    """Per-clip mean squared reconstruction error (higher => more anomalous)."""
    model.eval()
    rows: list[dict] = []
    for batch in loader:
        x = batch["x"].to(device)
        recon = model(x)
        err = torch.mean((recon - x) ** 2, dim=(1, 2, 3))
        names = batch["name"]
        paths = batch["path"]
        labels = batch.get("y")
        for i in range(x.size(0)):
            row = {
                "path": paths[i],
                "name": names[i],
                "score": float(err[i].item()),
            }
            if labels is not None:
                row["label"] = int(labels[i].item())
            rows.append(row)
    return pd.DataFrame(rows)


def partial_auc(fpr: np.ndarray, tpr: np.ndarray, max_fpr: float = 0.1) -> float:
    """Area under ROC for FPR in [0, max_fpr], horizontal axis scaled to [0, 1]."""
    idx = np.searchsorted(fpr, max_fpr, side="right")
    fpr_sel = np.concatenate([[0.0], fpr[:idx], [max_fpr]])
    tpr_sel = np.concatenate([[0.0], tpr[:idx], [np.interp(max_fpr, fpr, tpr)]])
    fpr_sel = np.clip(fpr_sel, 0.0, max_fpr)
    x = fpr_sel / max_fpr
    if hasattr(np, "trapezoid"):
        return float(np.trapezoid(tpr_sel, x))
    return float(np.trapz(tpr_sel, x))


def binary_metrics(y_true: np.ndarray, y_score: np.ndarray) -> dict[str, float]:
    fpr, tpr, _ = roc_curve(y_true, y_score)
    return {
        "auc": float(auc(fpr, tpr)),
        "pauc_0.1": partial_auc(fpr, tpr, max_fpr=0.1),
    }


def evaluate_dev_sections(scores: pd.DataFrame) -> pd.DataFrame:
    """Expect columns: section, label, score."""
    out_rows = []
    for sec, g in scores.groupby("section"):
        m = binary_metrics(g["label"].to_numpy(), g["score"].to_numpy())
        out_rows.append({"section": sec, **m, "n": len(g)})
    return pd.DataFrame(out_rows).sort_values("section")


def overall_metrics(scores: pd.DataFrame) -> dict[str, float]:
    """ROC AUC and pAUC (FPR≤0.1) over all rows; expects columns `label`, `score`."""
    return binary_metrics(scores["label"].to_numpy(), scores["score"].to_numpy())


def evaluation_report_markdown(scores: pd.DataFrame) -> str:
    """Human-readable summary: overall metrics + per-section table."""
    overall = overall_metrics(scores)
    per_sec = evaluate_dev_sections(scores)
    lines = [
        "### Evaluation metrics (development test)",
        "",
        f"- **AUC (overall):** {overall['auc']:.4f}",
        f"- **pAUC @ FPR≤0.1 (overall):** {overall['pauc_0.1']:.4f}",
        f"- **N clips:** {len(scores)}",
        "",
        "**Per section (bearing dev 00–02):**",
        "",
        per_sec.to_string(index=False),
    ]
    return "\n".join(lines)


def load_model_weights(model: torch.nn.Module, checkpoint_path: Path, device: torch.device) -> None:
    """Load `state_dict` from `training.fit` checkpoint."""
    path = Path(checkpoint_path)
    state = torch.load(path, map_location=device)
    model.load_state_dict(state["model"])
    model.to(device)
    model.eval()


def save_scores_csv(df: pd.DataFrame, path: Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df[["name", "score"]].to_csv(path, index=False, header=False)
