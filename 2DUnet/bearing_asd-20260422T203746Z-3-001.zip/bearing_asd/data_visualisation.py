"""Plots for waveforms and spectrograms."""

from __future__ import annotations

from pathlib import Path

import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np

from bearing_asd.config import AudioFeatureConfig
from bearing_asd.data_loading import fix_time_frames, waveform_to_log_mel


def plot_waveform_and_mel(
    wav_path: str | Path,
    feat: AudioFeatureConfig,
    title: str | None = None,
    figsize: tuple[float, float] = (12, 4),
) -> plt.Figure:
    wav_path = Path(wav_path)
    y, sr = librosa.load(str(wav_path), sr=feat.sample_rate, mono=True)
    spec = waveform_to_log_mel(y, sr, feat)
    spec = fix_time_frames(spec, feat.mel_time_frames)

    fig, axes = plt.subplots(1, 2, figsize=figsize)
    t = np.arange(len(y)) / sr
    axes[0].plot(t, y, linewidth=0.5)
    axes[0].set_title("Waveform")
    axes[0].set_xlabel("Time (s)")
    axes[0].set_ylabel("Amplitude")

    im = axes[1].imshow(spec, aspect="auto", origin="lower", cmap="magma")
    axes[1].set_title("Log-mel (pre norm.)")
    axes[1].set_xlabel("Time frame")
    axes[1].set_ylabel("Mel bin")
    fig.colorbar(im, ax=axes[1], fraction=0.046, pad=0.04)
    fig.suptitle(title or wav_path.name)
    fig.tight_layout()
    return fig


def plot_mel_grid(
    tensors: np.ndarray,
    titles: list[str] | None = None,
    ncols: int = 4,
    figsize_per_cell: tuple[float, float] = (3.0, 2.5),
) -> plt.Figure:
    """`tensors`: (N, H, W) mel maps."""
    n = tensors.shape[0]
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(
        nrows,
        ncols,
        figsize=(figsize_per_cell[0] * ncols, figsize_per_cell[1] * nrows),
        squeeze=False,
    )
    for i in range(nrows * ncols):
        r, c = divmod(i, ncols)
        ax = axes[r][c]
        if i < n:
            ax.imshow(tensors[i], aspect="auto", origin="lower", cmap="magma")
            ax.set_title(titles[i] if titles else f"#{i}")
        ax.axis("off")
    fig.tight_layout()
    return fig
