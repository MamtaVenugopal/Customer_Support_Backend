"""Model parameter counts and optional `torchinfo` summary."""

from __future__ import annotations

import torch.nn as nn

from bearing_asd.model_unet import count_parameters


def print_model_summary(
    model: nn.Module,
    *,
    input_shape: tuple[int, int, int, int] = (1, 1, 128, 256),
    device: str = "cpu",
) -> None:
    """Print trainable parameter count and, if installed, a layer-wise summary."""
    print(f"Trainable parameters: {count_parameters(model):,}")
    try:
        from torchinfo import summary  # type: ignore

        summary(model, input_size=input_shape, device=device)
    except ImportError:
        print("(Install `torchinfo` for a full layer-wise summary: pip install torchinfo)")
