"""Paths and hyperparameters shared across the pipeline."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class Paths:
    project_root: Path
    eval_train_zip: Path
    eval_test_zip: Path
    dev_zip: Path | None = None
    unpack_eval_dir: Path | None = None
    unpack_dev_dir: Path | None = None

    def __post_init__(self) -> None:
        self.project_root = Path(self.project_root).resolve()
        self.eval_train_zip = Path(self.eval_train_zip)
        self.eval_test_zip = Path(self.eval_test_zip)
        if self.dev_zip is not None:
            self.dev_zip = Path(self.dev_zip)
        self.unpack_eval_dir = Path(self.unpack_eval_dir or self.project_root / "data" / "dcase_bearing_eval")
        self.unpack_dev_dir = Path(self.unpack_dev_dir or self.project_root / "data" / "dcase_bearing_dev")


@dataclass
class AudioFeatureConfig:
    sample_rate: int = 16_000
    n_fft: int = 1024
    hop_length: int = 512
    n_mels: int = 128
    mel_time_frames: int = 256


@dataclass
class TrainConfig:
    batch_size: int = 16
    epochs: int = 5
    learning_rate: float = 1e-3
    val_fraction: float = 0.1
    num_workers: int = 0
    seed: int = 42
    device: str = "cuda"


def default_paths(project_root: Path | None = None) -> Paths:
    root = Path(project_root or Path.cwd()).resolve()
    return Paths(
        project_root=root,
        eval_train_zip=root / "eval_data_bearing_train.zip",
        eval_test_zip=root / "eval_data_bearing_test.zip",
        dev_zip=root / "dev_bearing.zip",
    )
