"""Human-readable dataset and task description (DCASE 2022 Task 2 — bearing slice)."""

from __future__ import annotations

DATASET_AND_USE_CASE = """
## What this data is

The archives follow **DCASE 2022 Challenge Task 2**: *Unsupervised Anomalous Sound Detection for Machine
Condition Monitoring with Domain Generalization* ([task overview](https://dcase.community/challenge2022/task-unsupervised-anomalous-sound-detection-for-machine-condition-monitoring#dataset-overview)).

- **Modality**: single-channel **audio**, **10 seconds** per clip, recorded in noisy factory-like conditions.
- **Machine focus here**: **bearing** sounds (one of seven machine types in the full benchmark).
- **Sections**: the **evaluation** track uses **sections 03–05** (different domain-shift scenarios than the
  **development** sections 00–02).

### `eval_data_bearing_train.zip`

- `bearing/train/`: **normal-only** clips for training (`section_03_*`, `section_04_*`, `section_05_*`).
- `bearing/attributes_0{3,4,5}.csv`: domain-shift parameters for **training** clips (e.g. velocity, mic
  location, factory noise mix), aligned with filenames.

### `eval_data_bearing_test.zip`

- `bearing/test/`: **unlabeled** test clips (`section_03_*.wav`, …). **No** normal/anomaly flag and **no**
  domain label — this matches the challenge **evaluation** setting.

### Optional `dev_bearing.zip` (recommended for *labeled* metrics)

- **Development** bearing data: **labeled** `test/` clips for sections **00–02** (`*_normal_*` / `*_anomaly_*`).
- Use this as a **separate generalization testbed**: train only on eval train (03–05), then measure AUC on
  dev test (00–02) to see how well the detector transfers across sections/domains.

---

## Problem statement (what you are solving)

1. **Unsupervised**: at deployment, you only have **normal** examples to train on (anomalies are rare and diverse).
2. **Domain shift**: train vs. test may differ in speed, noise, mic placement, etc.
3. **Domain generalization**: in evaluation audio, **domain is unknown**; a practical system should output a
   scalar **anomaly score** per clip (higher → more anomalous) with **one** decision threshold, not per-domain tuning.

### This notebook’s modeling choice

We use a **2D U-Net autoencoder** on **log-mel spectrograms**: the model learns to reconstruct **normal**
spectrograms. At test time, **mean squared reconstruction error** is the anomaly score (same spirit as the
official AE baseline, but convolutional and spatial).
"""


def print_dataset_overview() -> None:
    """Print dataset / task overview (for scripts or notebooks)."""
    print(DATASET_AND_USE_CASE.strip())


def get_dataset_overview_markdown() -> str:
    """Return markdown string for notebook display."""
    return DATASET_AND_USE_CASE.strip()
